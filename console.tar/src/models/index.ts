import user from './user';
import menus from './menus';
import material from './material';

export default [menus, user, material];
